<?php
namespace App;

use App\Controllers\AuthController;
use App\Controllers\JobController;

class Router {
    private $method;
    private $path;

    public function __construct() {
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    }

    public function route() {
        try {
            // Auth routes
            if ($this->path === '/api/register' && $this->method === 'POST') {
                $controller = new AuthController();
                $controller->register();
                return;
            }

            if ($this->path === '/api/login' && $this->method === 'POST') {
                $controller = new AuthController();
                $controller->login();
                return;
            }

            // Job routes
            if ($this->path === '/api/jobs' && $this->method === 'GET') {
                $controller = new JobController();
                $controller->list();
                return;
            }

            if ($this->path === '/api/jobs' && $this->method === 'POST') {
                $controller = new JobController();
                $controller->create();
                return;
            }

            if (preg_match('/^\/api\/jobs\/(\d+)\/assign$/', $this->path, $matches) && $this->method === 'POST') {
                $controller = new JobController();
                $controller->assign($matches[1]);
                return;
            }

            if (preg_match('/^\/api\/jobs\/(\d+)\/complete$/', $this->path, $matches) && $this->method === 'PATCH') {
                $controller = new JobController();
                $controller->complete($matches[1]);
                return;
            }

            http_response_code(404);
            echo json_encode(['error' => 'Route not found']);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
}
