<?php
namespace App\Services;

use DateTime;
use DateTimeZone;

class TimezoneService {
    private static $timezones = [
        'UK' => 'Europe/London',
        'MEXICO' => 'America/Mexico_City',
        'INDIA' => 'Asia/Kolkata'
    ];

    public static function convertToUTC($dateTimeString, $location) {
        if (!isset(self::$timezones[$location])) {
            throw new \Exception("Invalid location: $location");
        }

        $timezone = new DateTimeZone(self::$timezones[$location]);
        $utcTimezone = new DateTimeZone('UTC');

        $dateTime = new DateTime($dateTimeString, $timezone);
        $dateTime->setTimezone($utcTimezone);

        return $dateTime->format('Y-m-d H:i:s');
    }

    public static function convertFromUTC($dateTimeString, $location) {
        if (!isset(self::$timezones[$location])) {
            throw new \Exception("Invalid location: $location");
        }

        $utcTimezone = new DateTimeZone('UTC');
        $localTimezone = new DateTimeZone(self::$timezones[$location]);

        $dateTime = new DateTime($dateTimeString, $utcTimezone);
        $dateTime->setTimezone($localTimezone);

        return $dateTime->format('Y-m-d H:i:s');
    }

    public static function getTimezoneForLocation($location) {
        return self::$timezones[$location] ?? null;
    }
}
