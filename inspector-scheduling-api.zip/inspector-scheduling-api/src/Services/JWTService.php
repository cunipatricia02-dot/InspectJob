<?php
namespace App\Services;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JWTService {
    private static $secret;
    private static $expiry;

    public static function init() {
        self::$secret = $_ENV['JWT_SECRET'];
        self::$expiry = $_ENV['JWT_EXPIRY'];
    }

    public static function encode($payload) {
        self::init();
        $issuedAt = time();
        $expire = $issuedAt + self::$expiry;

        $token = [
            'iat' => $issuedAt,
            'exp' => $expire,
            'data' => $payload
        ];

        return JWT::encode($token, self::$secret, 'HS256');
    }

    public static function decode($token) {
        self::init();
        try {
            $decoded = JWT::decode($token, new Key(self::$secret, 'HS256'));
            return $decoded->data;
        } catch (\Exception $e) {
            return null;
        }
    }

    public static function getAuthUser() {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;

        if (!$authHeader || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];
        return self::decode($token);
    }

    public static function requireAuth() {
        $user = self::getAuthUser();
        if (!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
        return $user;
    }
}
