-- Sample data for testing

USE inspector_scheduling;

-- Insert sample inspectors
INSERT INTO inspectors (email, password, name, location) VALUES
('uk.inspector@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Alice Smith', 'UK'),
('mexico.inspector@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Carlos Rodriguez', 'MEXICO'),
('india.inspector@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Priya Sharma', 'INDIA');

-- Password for all sample users is: password

-- Insert sample jobs
INSERT INTO jobs (title, description, status) VALUES
('Office Building Inspection', 'Annual safety and compliance inspection for 10-story office building', 'available'),
('Residential Property Check', 'Pre-purchase inspection of 3-bedroom house', 'available'),
('Factory Safety Audit', 'Quarterly safety audit of manufacturing facility', 'available'),
('Restaurant Health Inspection', 'Food safety and hygiene inspection', 'available'),
('School Building Assessment', 'Structural integrity assessment of school facilities', 'available');
